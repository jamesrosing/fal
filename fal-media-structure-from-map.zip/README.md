﻿# FAL Media Structure (Based on Usage Map)

This structure reflects the directories identified in the media usage map.
Place your media files accordingly.

After filling this structure with your images:
1. ZIP the entire 'fal-media-structure-from-map' folder.
2. Upload the ZIP back to the project.
3. Extract the 'public' and 'components' folders into your project root.
4. Run: npm run media:register
